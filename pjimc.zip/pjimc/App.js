import *  as React from 'react';
import { useState } from 'react';
import { Text, View, StyleSheet, TextInput, Button, Image} from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
    const [peso, setPeso] = useState();
    const [altura, setAltura] = useState();
    const [imc, setImc] = useState();
    
  function calcular(){
     setImc(parseFloat(peso)/parseFloat(altura)*parseFloat(altura));

    alert(setImc);
    }
  
  return (
  <View style={styles.container}>
    <Card>
      <Text style={styles.paragraph}>
        Calculadora de IMC
      </Text>

      <Text style={styles.texto}>Peso :</Text>

      <TextInput style={styles.caixa} 
      placeholder="Coloque seu Peso" 
      value={peso} 
      onChangeText={(text)=> setPeso(text)}
      />

      <Text style={styles.texto}>Altura :</Text>

      <TextInput style={styles.caixa} 
      placeholder="Coloque sua Altura" 
      value={altura} 
      onChangeText={(text) => setAltura(text)}
      />

      <Text style={styles.texto}>IMC :</Text>

      <TextInput editable={false} style={styles.caixa} placeholder="Seu IMC Atual" value={this.imc}/>

      <View style={styles.botao}>
        <Button title='Calcular'  onPress={() => calcular(peso,altura)}/>
      </View>

    </Card>
  
  </View>
  );
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#7276A8',
    padding: 20,
  },
  paragraph: {
    margin: 15,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  texto: {
    marginLeft: 20,
  },
  caixa :{
    height: 30,
    marginLeft: 20,
    marginRight: 20,
    marginTop: 10,
    marginBottom: 15,
    borderWidth: 1,
    padding: 10,
    backgroundColor: '#E6E6ED',
  },
  botao :{
    width:'60%',
    alignSelf:'center',
    marginBottom:30,
  },
});
