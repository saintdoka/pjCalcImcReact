import *  as React from 'react';
import { useState } from 'react';
import { 
  Text,
  View, 
  StyleSheet, 
  TextInput,
  Button, 
  Image,
  TouchableOpacity
} from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default class App extends React.Component {
    constructor(props){
      super(props)
      this.state = {altura:0,massa:0,resultado:0,resultadoText:""}
      this.calcular = this.calcular.bind(this) 
    } //Este é o método 
    
    calcular(){
      let imc = this.state.massa / (this.state.altura * this.state.altura)
      let s = this.state
      s.resultado = imc

      if(s.resultado < 18.5){
        s.resultadoText ='Abaixo do Peso'
      }
        else if (s.resultado < 25){
        s.resultadoText ='Peso Normal'
        }
        else if (s.resultado < 30){
        s.resultadoText ='Sobrepeso'
        }
        else if (s.resultado < 35) {
        s.resultadoText ='Obesidade grau I'
        }
        else if (s.resultado < 40) {
        s.resultadoText ='Obesidade grau II'
        }
        else{
          s.resultadoText ='Obesidade Grau III'
        }
      this.setState(s)
    }
  render(){
  return (
  <View style={styles.container}>
    <Card>
      <Text style={styles.paragraph}>
        Calculadora de IMC
      </Text>

      <Text style={styles.texto}>Peso :</Text>

      <TextInput style={styles.caixa} 
      placeholder="Coloque seu Peso"  
      onChangeText={(massa)=>{this.setState({massa})}}
      />

      <Text style={styles.texto}>Altura :</Text>

      <TextInput style={styles.caixa} 
      placeholder="Coloque sua Altura"
      onChangeText={(altura)=>{this.setState({altura})}}
      />

      <Text style={styles.texto}>IMC :</Text>

      <TextInput editable={false} style={styles.caixa} placeholder="Seu IMC Atual" value={this.state.resultado.toFixed(2)} />
      

      <View style={styles.botao}>
        <Button title='Calcular'  onPress={this.calcular}/>
      </View>

    </Card>
  
  </View>
  );
  }
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#7276A8',
    padding: 20,
  },
  paragraph: {
    margin: 15,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  texto: {
    marginLeft: 20,
  },
  caixa :{
    height: 30,
    marginLeft: 20,
    marginRight: 20,
    marginTop: 10,
    marginBottom: 15,
    borderWidth: 1,
    padding: 10,
    backgroundColor: '#E6E6ED',
  },
  botao :{
    width:'60%',
    alignSelf:'center',
    marginBottom:30,
  },
});
